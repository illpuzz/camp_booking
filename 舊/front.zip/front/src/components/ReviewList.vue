<!-- src/components/ReviewList.vue -->
<template>
  <div class="review-list-container">
    <!-- 載入中 -->
    <div v-if="loading" class="loading-state text-center py-5">
      <div class="spinner-border text-danger" role="status">
        <span class="visually-hidden">載入中...</span>
      </div>
      <p class="mt-2 text-forest">評價載入中，請稍候...</p>
    </div>

    <!-- 錯誤訊息 -->
    <div v-else-if="error" class="alert-box alert-danger">
      <i class="bi bi-exclamation-triangle-fill me-2"></i>
      <div>{{ error }}</div>
    </div>

    <!-- 無評價提示 -->
    <div v-else-if="!loading && !error && reviews.length === 0" class="empty-state text-center">
      <i class="bi bi-chat-square-text empty-icon"></i>
      <h3 class="text-forest">暫無評價</h3>
      <p class="text-forest">成為第一個評價此營地的人吧！</p>
    </div>

    <!-- 評價列表 -->
    <div v-else>
      <h2 class="section-title text-forest">
        <i class="bi bi-list-stars me-2"></i>
        評價列表 <span class="count">({{ totalElements || reviews.length }})</span>
      </h2>

      <div class="review-list-vertical">
  <div v-for="review in reviews" :key="review.id" class="review-card-wrapper mb-4">
    <!-- 當評價被檢舉時顯示提示訊息 -->
    <div v-if="review.isReported" class="reported-item">
      <i class="bi bi-shield-exclamation me-2"></i>
      此評價已被檢舉，正在審核中
    </div>
    <!-- 否則顯示正常評價 -->
    <div v-else class="review-item">
      <!-- Header -->
      <div class="d-flex justify-content-between align-items-start review-header">
        <div class="d-flex align-items-center">
          <div>
            <span class="camp-region text-forest">{{ getCampRegion(review.campSiteId) }}</span>
            <a :href="`/campsites/${review.campSiteId}`" class="camp-name text-forest ms-1">{{ getCampName(review.campSiteId) }}</a>
          </div>
        </div>
        <div class="star-rating overall-rating">
          <span v-for="i in 5" :key="i" :class="['star', i <= review.overallRating ? 'star-filled' : 'star-empty']">★</span>
        </div>
      </div>

            <!-- User Info -->
            <div class="d-flex justify-content-between align-items-center mt-3 user-info">
              <div>
                <h3 class="user-name mb-1 text-forest">{{ review.userName || '匿名用戶' }}</h3>
                <p class="review-date mb-0 text-forest-light">
  {{ formatDate(review.createdAt) }}
  <span v-if="review.updatedAt && new Date(review.updatedAt).getTime() > new Date(review.createdAt).getTime() + 60000" class="edited-tag">
    (已編輯)
  </span>
</p>
              </div>
              
              <!-- 管理操作按鈕區 (顯示在右上角) - 臨時保持始終顯示 -->
              <div class="admin-actions">
                <!-- 編輯按鈕 -->
                <button 
                  type="button"
                  class="admin-btn edit-btn" 
                  @click.stop="openEditModal(review)"
                  title="編輯評價"
                >
                  <i class="bi bi-pencil-fill"></i> 編輯
                </button>
                
                <!-- 刪除按鈕 -->
                <button 
                  type="button"
                  class="admin-btn delete-btn" 
                  @click.stop="openDeleteModal(review)"
                  title="刪除評價"
                >
                  <i class="bi bi-trash"></i> 刪除
                </button>
              </div>
            </div>

            <!-- Content -->
            <p class="review-text mt-3 text-forest">{{ review.reviewText }}</p>

            <!-- Pros & Cons -->
            <div class="pros-cons mt-3" v-if="review.pros || review.cons">
              <div v-if="review.pros" class="pros">
                <span class="label"><i class="bi bi-hand-thumbs-up-fill me-1"></i>優點：</span>
                <span class="value text-forest">{{ review.pros }}</span>
              </div>
              <div v-if="review.cons" class="cons">
                <span class="label"><i class="bi bi-hand-thumbs-down-fill me-1"></i>缺點：</span>
                <span class="value text-forest">{{ review.cons }}</span>
              </div>
            </div>

            <!-- Ratings Detail -->
            <div class="rating-details">
              <div class="rating-item">
                <span class="rating-label text-forest">清潔程度</span>
                <span class="star-rating">
                  <span v-for="i in 5" :key="i" :class="['star', i <= review.cleanlinessRating ? 'star-filled' : 'star-empty']">★</span>
                </span>
              </div>
              <div class="rating-item">
                <span class="rating-label text-forest">便利程度</span>
                <span class="star-rating">
                  <span v-for="i in 5" :key="i" :class="['star', i <= review.convenienceRating ? 'star-filled' : 'star-empty']">★</span>
                </span>
              </div>
              <div class="rating-item">
                <span class="rating-label text-forest">友善程度</span>
                <span class="star-rating">
                  <span v-for="i in 5" :key="i" :class="['star', i <= review.friendlinessRating ? 'star-filled' : 'star-empty']">★</span>
                </span>
              </div>
            </div>

            <!-- Images -->
            <div v-if="review.imageUrls && review.imageUrls.length" class="review-images">
              <div v-for="(url, idx) in getVisibleImages(review.imageUrls)" :key="idx" class="image-wrapper">
                <div class="image-loading" v-if="isImageLoading(`review-${review.id}-img-${idx}`)">
                  <div class="spinner-border spinner-border-sm" role="status">
                    <span class="visually-hidden">載入中...</span>
                  </div>
                </div>
                <img 
                  :src="url" 
                  :alt="`評價照片 ${idx + 1}`" 
                  class="img-fluid rounded review-image" 
                  @click.stop="viewImage(review.imageUrls, idx)" 
                  @load="handleImageLoaded(`review-${review.id}-img-${idx}`)"
                  @error="logImageError($event, `review-${review.id}-img-${idx}`, url)"
                  :class="{'d-none': isImageLoading(`review-${review.id}-img-${idx}`)}"
                  referrerpolicy="no-referrer"
                />
                <div class="image-overlay">
                  <i class="bi bi-zoom-in"></i>
                </div>
              </div>
              <div v-if="review.imageUrls.length > 3" class="more-images" @click.stop="viewImage(review.imageUrls, 3)">
                <span>+{{ review.imageUrls.length - 3 }}</span>
              </div>
            </div>

            <div v-if="review.replyText && review.replyText.trim()" class="reply-section">
  <!-- 如果回覆被檢舉，顯示被檢舉提示 -->
  <div v-if="review.isReplyReported" class="reported-reply">
    <i class="bi bi-shield-exclamation me-2"></i>
    此回覆已被檢舉，正在審核中
  </div>
  <!-- 否則顯示正常回覆 -->
  <div v-else>
    <div class="reply-header-container">
      <h6 class="reply-header text-forest">
        <i class="bi bi-chat-left-text me-2"></i>營地方回覆：
      </h6>

      <!-- 僅在是營地主人且有回覆時顯示 -->
      <div class="reply-actions" v-if="isOwner && review.replyText && review.replyText.trim()">
      </div>
    </div>

    <p class="reply-content text-forest">{{ review.replyText }}</p>
  </div>

  <!-- 回覆檢舉按鈕 -->
 <div class="d-flex justify-content-end align-items-center mt-2">
  <button 
    v-if="isOwner && review.replyText && review.replyText.trim() && !review.isReplyReported"
    type="button"
    class="btn btn-outline-success btn-sm me-2"
    @click.stop="openEditReplyModal(review)"
    title="編輯回覆"
  >
    <i class="bi bi-pencil-fill me-1"></i> 編輯
  </button>

  <button 
    v-if="isOwner && review.replyText && review.replyText.trim() && !review.isReplyReported"
    type="button"
    class="btn btn-outline-danger btn-sm me-2"
    @click.stop="openDeleteReplyModal(review)"
    title="刪除回覆"
  >
    <i class="bi bi-trash-fill me-1"></i> 刪除
  </button>

  <button 
    v-if="!review.isReplyReported"
    type="button"
    class="btn btn-outline-secondary btn-sm"
    @click.stop="openReportReplyModal(review)"
  >
    <i class="bi bi-flag me-1"></i> 檢舉回覆
  </button>
</div>
</div>

            <!-- Actions -->
            <div class="review-actions">
              <div class="action-group view-edit">
                <a 
                  :href="`/reviews/${review.id}`"
                  class="action-btn view-btn text-forest" 
                  @click.stop="viewReview(review.id, $event)"
                >
                  <i class="bi bi-eye me-1"></i> 查看
                </a>
                
                <!-- 回覆按鈕 (僅顯示給營主，且評價尚未回覆) -->
                <button 
                  type="button"
                  v-if="isOwner && !review.replyText" 
                  class="action-btn reply-btn" 
                  @click.stop="openReplyModal(review)"
                >
                  <i class="bi bi-chat-dots me-1"></i> 回覆
                </button>
              </div>
              
              <!-- 點讚和檢舉按鈕 - 移到右下角 -->
              <div class="right-bottom-actions">
                <!-- 點讚按鈕 -->
                <button 
                  type="button"
                  class="action-btn like-btn" 
                  :class="{ 'active': review.userLikeStatus === 1 }" 
                  @click.stop="handleLike(review.id)"
                >
                  <i class="bi" :class="review.userLikeStatus === 1 ? 'bi-hand-thumbs-up-fill me-1' : 'bi-hand-thumbs-up me-1'"></i>
                  {{ review.likeCount || 0 }} 讚
                </button>
                
                <!-- 評價檢舉按鈕 - 無條件顯示 -->
                <button 
                  type="button"
                  class="action-btn report-btn" 
                  @click.stop="openReportModal(review)"
                >
                  <i class="bi bi-flag me-1"></i> 檢舉
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- 分頁 -->
      <nav v-if="totalPages > 1" class="pagination-container">
        <ul class="pagination">
          <li class="page-item" :class="{ disabled: currentPage === 0 }">
            <a class="page-link" href="#" @click.prevent="currentPage > 0 && changePage(currentPage - 1)">
              <i class="bi bi-chevron-left"></i>
            </a>
          </li>
          <li v-for="page in displayPages" :key="page" class="page-item" :class="{ active: currentPage === page }">
            <a class="page-link" href="#" @click.prevent="changePage(page)">{{ page + 1 }}</a>
          </li>
          <li class="page-item" :class="{ disabled: currentPage >= totalPages - 1 }">
            <a class="page-link" href="#" @click.prevent="currentPage < totalPages - 1 && changePage(currentPage + 1)">
              <i class="bi bi-chevron-right"></i>
            </a>
          </li>
        </ul>
      </nav>
    </div>
    
    <!-- 圖片查看器 -->
    <ImageViewer
      v-if="showImageViewer"
      :images="selectedImages"
      :startIndex="selectedImageIndex"
      :visible="showImageViewer"
      @close="closeImageViewer"
    />
    
    <!-- 編輯評價模態框 -->
    <EditReviewModal
      v-if="showEditModal"
      :show="showEditModal"
      :review="selectedReview"
      @close="closeEditModal"
      @update="updateReview"
    />
    
    <!-- 刪除評價確認模態框 -->
    <DeleteConfirmModal
      v-if="showDeleteModal"
      :show="showDeleteModal"
      :review="selectedReview"
      :item-type="'評價'"
      @close="closeDeleteModal"
      @confirm="deleteReview"
    />
    
    <!-- 刪除回覆確認模態框 -->
    <DeleteConfirmModal
      v-if="showDeleteReplyModal"
      :show="showDeleteReplyModal"
      :review="selectedReview"
      :item-type="'回覆'"
      @close="closeDeleteReplyModal"
      @confirm="deleteReply"
    />
    
    <!-- 回覆評價模態框 -->
    <ReplyReviewModal
      v-if="showReplyModal"
      :show="showReplyModal"
      :review="selectedReview"
      @close="closeReplyModal"
      @submit="submitReply"
    />
    
    <!-- 編輯回覆模態框 -->
    <EditReplyModal
      v-if="showEditReplyModal"
      :show="showEditReplyModal"
      :review="selectedReview"
      @close="closeEditReplyModal"
      @update="updateReply"
    />
    
    <!-- 評價檢舉模態框 -->
    <ReportModal
      v-if="showReportModal"
      :show="showReportModal"
      :review-id="selectedReview?.id || 0"
      :user-id="currentUserId"
      @cancel="closeReportModal"
      @submit="submitReport"
    />

    <!-- 回覆檢舉模態框 -->
    <ReportModal
      v-if="showReportReplyModal"
      :show="showReportReplyModal"
      :review-id="selectedReview?.id || 0"
      :user-id="currentUserId"
      :is-reply="true"
      @cancel="closeReportReplyModal"
      @submit="submitReplyReport"
    />
  </div>
</template>

<script>
import { ref, computed, onMounted, watch } from 'vue';
import { useRouter } from 'vue-router';
import { useAuthStore } from '../stores/auth';
import axios from 'axios';
import ImageViewer from './ImageViewer.vue';
import EditReviewModal from './EditReviewModal.vue';
import DeleteConfirmModal from './DeleteConfirmModal.vue';
import ReplyReviewModal from './ReplyReviewModal.vue';
import EditReplyModal from './EditReplyModal.vue';
import ReportModal from './ReportModal.vue';
import Swal from 'sweetalert2';

// 檢查所有導入的組件
console.log('檢查組件導入狀態:', {
  'ImageViewer': typeof ImageViewer === 'object',
  'EditReviewModal': typeof EditReviewModal === 'object',
  'DeleteConfirmModal': typeof DeleteConfirmModal === 'object',
  'ReplyReviewModal': typeof ReplyReviewModal === 'object',
  'EditReplyModal': typeof EditReplyModal === 'object',
  'ReportModal': typeof ReportModal === 'object'
});

export default {
  name: 'ReviewList',
  components: {
    ImageViewer,
    EditReviewModal,
    DeleteConfirmModal,
    ReplyReviewModal,
    EditReplyModal,
    ReportModal
  },
  props: {
    campSiteId: { 
      type: [Number, String], 
      required: true 
    },
    searchParams: { 
      type: Object, 
      default: () => ({ 
        keyword: '', 
        sortBy: 'overallRating', 
        sortDirection: 'DESC', 
        ratingFilters: {
          overallRating: 0,
          cleanlinessRating: 0,
          convenienceRating: 0,
          friendlinessRating: 0
        } 
      }) 
    }
  },
  setup(props) {
    const router = useRouter();
    const authStore = useAuthStore();

    // 基本狀態
    const reviews = ref([]);
    const loading = ref(true);
    const error = ref('');
    const currentPage = ref(0);
    const totalPages = ref(0);
    const totalElements = ref(0);
    const pageSize = ref(5);
    const currentUserId = computed(() => authStore.userId || 1);
    
    // 圖片查看器相關狀態
    const showImageViewer = ref(false);
    const selectedImages = ref([]);
    const selectedImageIndex = ref(0);
    
    // 圖片載入狀態
    const loadingImages = ref({});
    
    // 模態框狀態
    const showEditModal = ref(false);
    const showDeleteModal = ref(false);
    const showReplyModal = ref(false);
    const showEditReplyModal = ref(false);
    const showDeleteReplyModal = ref(false);
    const showReportModal = ref(false);
    const showReportReplyModal = ref(false);
    const selectedReview = ref(null);
    
    // 是否為營地主人
    const isOwner = ref(true); // 實際應從用戶權限獲取

    // 營地資料
    const campSites = {
      1: { name: '山之間', region: '苗栗區' },
      2: { name: '海岸營地', region: '花蓮' },
      3: { name: '森林營區', region: '南投' },
      4: { name: '溪畔營地', region: '宜蘭' },
      5: { name: '山海營區', region: '台東' }
    };
    
    // 獲取營地名稱
    const getCampName = (campSiteId) => {
      return campSites[campSiteId]?.name || `營地 #${campSiteId}`;
    };
    
    // 獲取營地區域
    const getCampRegion = (campSiteId) => {
      return campSites[campSiteId]?.region || '';
    };

    // 格式化日期
    const formatDate = (dateString) => {
      if (!dateString) return '';
      
      try {
        const date = new Date(dateString);
        return `${date.getFullYear()}年${date.getMonth() + 1}月${date.getDate()}日`;
      } catch (e) {
        console.error('日期格式化錯誤:', e);
        return dateString;
      }
    };
    
    // 圖片載入狀態管理
    const isImageLoading = (imageId) => {
      return loadingImages.value[imageId] === true;
    };
    
    const handleImageLoaded = (imageId) => {
      loadingImages.value[imageId] = false;
    };
    
// 圖片載入錯誤處理 - 簡化版
const logImageError = (event, imageId, url) => {
  console.error(`圖片載入失敗: ${url}`);
  loadingImages.value[imageId] = false;
  
  if (event.target) {
    event.target.classList.remove('d-none');
    event.target.src = window.DEFAULT_IMAGE_PLACEHOLDER;
  }
};
        
 // 獲取可見圖片 - 修復版
const getVisibleImages = (imageUrls) => {
  if (!imageUrls || !imageUrls.length) return [];
  
  // 添加除錯日誌
  console.log('原始圖片URLs:', imageUrls);
  
  const processedUrls = imageUrls.slice(0, 3).map(url => {
    const processedUrl = window.getImageUrl(url);
    console.log(`處理URL: 原始=${url}, 處理後=${processedUrl}`);
    return processedUrl;
  });
  
  console.log('處理後的圖片URLs:', processedUrls);
  return processedUrls;
};

// onMounted 中使用以下代碼取代 testApiConnection 的調用
onMounted(async () => {
  // 使用已有的API連接狀態
  const apiStatus = sessionStorage.getItem('API_CONNECTION_STATUS');
  
  if (apiStatus !== 'success') {
    error.value = 'API連接可能有問題，部分功能可能無法正常運作';
  }
  
  // 繼續原有的初始化
  fetchReviews();
});

    // 載入評價
    const fetchReviews = async () => {
      loading.value = true;
      error.value = '';
      
      try {
        // 構建API參數
        const params = { 
          campSiteId: props.campSiteId, 
          page: currentPage.value, 
          size: pageSize.value, 
          userId: currentUserId.value,
          sortBy: props.searchParams.sortBy,
          direction: props.searchParams.sortDirection
        };
        
        // 添加篩選條件
        const ratings = props.searchParams.ratingFilters;
        if (ratings.overallRating > 0) {
          console.log(`設定最小總體評分: ${ratings.overallRating}`);
          params.minRating = ratings.overallRating;
        }
        if (ratings.cleanlinessRating > 0) {
          console.log(`設定最小清潔度評分: ${ratings.cleanlinessRating}`);
          params.minCleanlinessRating = ratings.cleanlinessRating;
        }
        if (ratings.convenienceRating > 0) {
          console.log(`設定最小便利性評分: ${ratings.convenienceRating}`);
          params.minConvenienceRating = ratings.convenienceRating;
        }
        if (ratings.friendlinessRating > 0) {
          console.log(`設定最小友善度評分: ${ratings.friendlinessRating}`);
          params.minFriendlinessRating = ratings.friendlinessRating;
        }
        
        // 添加關鍵字搜尋
        if (props.searchParams.keyword) {
          params.keyword = props.searchParams.keyword;
        }
        
        console.log('API請求參數:', params);
        
        const apiUrl = `/api/reviews`;
        const response = await axios.get(apiUrl, { params, timeout: 5000 });
        const data = response.data;
        
        // 解析數據
        if (data && data.content) {
          // 檢查服務器返回的數據是否符合篩選條件
          console.log('服務器返回評價數:', data.content.length);
          
          // 在前端進行額外過濾
          let filteredContent = data.content;
          if (ratings.overallRating > 0) {
            filteredContent = filteredContent.filter(review => review.overallRating >= ratings.overallRating);
            console.log(`前端過濾後（總體評分 >= ${ratings.overallRating}）的評價數:`, filteredContent.length);
          }
          if (ratings.cleanlinessRating > 0) {
            filteredContent = filteredContent.filter(review => review.cleanlinessRating >= ratings.cleanlinessRating);
            console.log(`前端過濾後（清潔度評分 >= ${ratings.cleanlinessRating}）的評價數:`, filteredContent.length);
          }
          if (ratings.convenienceRating > 0) {
            filteredContent = filteredContent.filter(review => review.convenienceRating >= ratings.convenienceRating);
            console.log(`前端過濾後（便利性評分 >= ${ratings.convenienceRating}）的評價數:`, filteredContent.length);
          }
          if (ratings.friendlinessRating > 0) {
            filteredContent = filteredContent.filter(review => review.friendlinessRating >= ratings.friendlinessRating);
            console.log(`前端過濾後（友善度評分 >= ${ratings.friendlinessRating}）的評價數:`, filteredContent.length);
          }
          
          // 使用過濾後的數據
          reviews.value = filteredContent;
          totalPages.value = data.totalPages || 1;
          totalElements.value = filteredContent.length; // 更新總數為過濾後的數量
          currentPage.value = data.number || 0;
        } else if (Array.isArray(data)) {
          reviews.value = data;
          totalPages.value = 1;
          totalElements.value = reviews.value.length;
          currentPage.value = 0;
        }
        
 // 簡化的圖片處理邏輯
 reviews.value.forEach(review => {
  // 確保有 imageUrls 陣列
  if (!review.imageUrls) {
    review.imageUrls = [];
  } 
  // 特別處理從後端獲取的 ReviewImage 對象數組
  else if (Array.isArray(review.imageUrls) && review.imageUrls.length > 0 && 
          typeof review.imageUrls[0] === 'object') {
    // 提取 imageUrl 欄位 (符合後端 ReviewImage.java 模型)
    review.imageUrls = review.imageUrls.map(img => img.imageUrl || '').filter(url => url);
  }
  
  // 初始化圖片載入狀態
  if (review.imageUrls.length > 0) {
    review.imageUrls.forEach((_, idx) => {
      const imageId = `review-${review.id}-img-${idx}`;
      loadingImages.value[imageId] = true;
    });
  }
});
        
        // 打印除錯信息
        console.log('==== 按鈕渲染狀態檢查 ====');
        reviews.value.forEach(review => {
          console.log(`評價 #${review.id} 按鈕狀態:`, {
            '評價 ID': review.id,
            '評價用戶 ID': review.userId,
            '當前用戶 ID': currentUserId.value,
            '是否當前用戶的評價': isCurrentUserReview(review),
            '編輯按鈕顯示': true,
            '刪除按鈕顯示': true,
            '檢舉按鈕顯示': true
          });
        });
        
      } catch (err) { // 使用不同變數名稱 'err'，避免與 ref 變數 'error' 衝突
        console.error('獲取評價失敗:', err);
        error.value = '獲取評價失敗，請稍後重試';
      } finally {
        loading.value = false;
      }
    };

    // 計算分頁顯示
    const displayPages = computed(() => {
      const pages = [];
      const maxDisplay = 5;
      
      if (totalPages.value <= maxDisplay) {
        for (let i = 0; i < totalPages.value; i++) {
          pages.push(i);
        }
      } else {
        let start, end;
        
        if (currentPage.value < Math.floor(maxDisplay / 2)) {
          start = 0;
          end = maxDisplay - 1;
        } else if (currentPage.value >= totalPages.value - Math.floor(maxDisplay / 2)) {
          start = totalPages.value - maxDisplay;
          end = totalPages.value - 1;
        } else {
          start = currentPage.value - Math.floor(maxDisplay / 2);
          end = currentPage.value + Math.floor(maxDisplay / 2);
        }
        
        start = Math.max(0, start);
        end = Math.min(totalPages.value - 1, end);
        
        for (let i = start; i <= end; i++) {
          pages.push(i);
        }
      }
      
      return pages;
    });

    // 頁面變更
    const changePage = (page) => { 
      if (page >= 0 && page < totalPages.value) { 
        currentPage.value = page; 
        fetchReviews(); 
      }
    };
    
    // 檢查是否為當前用戶的評價 (開發階段暫時返回true，方便測試)
    const isCurrentUserReview = (review) => {
      // 實際應該按此邏輯判斷: return review.userId === currentUserId.value;
      // 暫時始終返回true，確保按鈕可見
      return true;
    };
    
    // 處理點讚 - 完全簡化版
    const handleLike = async (reviewId) => {
      try {
        const targetReview = reviews.value.find(r => r.id === reviewId);
        
        if (!targetReview) return;
        
        // 先在本地更新狀態以提升用戶體驗
        const isLiked = targetReview.userLikeStatus === 1;
        
        // 切換點讚狀態
        targetReview.userLikeStatus = isLiked ? 0 : 1;
        // 更新讚數
        targetReview.likeCount = isLiked ? 
          Math.max(0, (targetReview.likeCount || 0) - 1) : 
          (targetReview.likeCount || 0) + 1;
        
        // 獲取當前用戶ID
        const userId = currentUserId.value;
        
        // 完全符合後端 API 格式的請求
        const response = await axios.post(`/api/reviews/${reviewId}/like?userId=${userId}`);
        
        console.log('點讚成功:', response.data);
        
      } catch (err) {
        console.error('點讚操作失敗:', err);
        
        // 如果失敗，恢復之前的狀態
        const targetReview = reviews.value.find(r => r.id === reviewId);
        if (targetReview) {
          const isLiked = targetReview.userLikeStatus === 1;
          targetReview.userLikeStatus = isLiked ? 0 : 1;
          targetReview.likeCount = isLiked ? 
            (targetReview.likeCount || 0) - 1 : 
            Math.max(0, (targetReview.likeCount || 0) + 1);
        }
      }
    };
    
    // 檢舉模態框相關 - 已增強
    const openReportModal = (review) => {
      console.log('打開檢舉模態框，評價ID:', review.id);
      
      // 確保深度複製評價對象，避免引用問題
      selectedReview.value = JSON.parse(JSON.stringify(review));
      
      // 確保模態框可見
      showReportModal.value = true;
      
      // 檢查模態框的狀態
      console.log('檢舉模態框狀態:', {
        'showReportModal': showReportModal.value,
        'selectedReview': selectedReview.value
      });
    };

    const closeReportModal = () => {
      showReportModal.value = false;
      selectedReview.value = null;
    };

    const openReportReplyModal = (review) => {
      console.log('打開回覆檢舉模態框，評價ID:', review.id);
      selectedReview.value = JSON.parse(JSON.stringify(review));
      showReportReplyModal.value = true;
    };

    const closeReportReplyModal = () => {
      showReportReplyModal.value = false;
      selectedReview.value = null;
    };

    const submitReport = async (reportData) => {
  console.log('提交檢舉:', reportData);
  
  try {
    // 直接提交到後端API
    const response = await axios.post('/api/review-reports', reportData);
    console.log('檢舉提交成功:', response.data);
    
    // 將檢舉的評價標記為已檢舉（在UI上隱藏或標記）
    const reviewIndex = reviews.value.findIndex(r => r.id === reportData.reviewId);
    if (reviewIndex !== -1) {
      // 可以選擇隱藏評價或添加已檢舉標記
      reviews.value[reviewIndex].isReported = true;
    }
    
    // 顯示成功訊息
    Swal.fire({
      icon: 'success',
      title: '檢舉已提交',
      text: '感謝您的回報，我們將盡快處理',
      confirmButtonColor: '#3a8c5f'
    });
  } catch (error) {
    console.error('檢舉API提交失敗:', error);
    // 顯示錯誤訊息
    Swal.fire({
      icon: 'error',
      title: '檢舉提交失敗',
      text: '請稍後再試',
      confirmButtonColor: '#3a8c5f'
    });
  }
  
  // 關閉模態框
  closeReportModal();
};

// 同樣修改回覆檢舉提交函數
const submitReplyReport = async (reportData) => {
  console.log('提交回覆檢舉:', reportData);
  
  try {
    // 添加標記指明這是對回覆的檢舉
    reportData.isReplyReport = true;
    
    // 直接提交到後端API
    const response = await axios.post('/api/review-reports', reportData);
    console.log('回覆檢舉提交成功:', response.data);
    
    // 將檢舉的回覆標記為已檢舉（在UI上隱藏或標記）
    const reviewIndex = reviews.value.findIndex(r => r.id === reportData.reviewId);
    if (reviewIndex !== -1) {
      // 可以選擇隱藏回覆或添加已檢舉標記
      reviews.value[reviewIndex].isReplyReported = true;
    }
    
    // 顯示成功訊息
    Swal.fire({
      icon: 'success',
      title: '檢舉已提交',
      text: '感謝您的回報，我們將盡快處理',
      confirmButtonColor: '#3a8c5f'
    });
  } catch (error) {
    console.error('回覆檢舉API提交失敗:', error);
    // 顯示錯誤訊息
    Swal.fire({
      icon: 'error',
      title: '檢舉提交失敗',
      text: '請稍後再試',
      confirmButtonColor: '#3a8c5f'
    });
  }
  
  // 關閉模態框
  closeReportReplyModal();
};
    
    // 檢視評價
    const viewReview = (reviewId, event) => {
      if (event) {
        event.preventDefault();
      }
      
      router.push(`/reviews/${reviewId}`);
      
      return false;
    };
    
    // 查看圖片 - 改進版
    const viewImage = (images, index) => {
      if (!images || !images.length) return;
      
      // 處理所有URL
      const processedImages = images.map(url => window.getImageUrl(url));
      
      selectedImages.value = processedImages;
      selectedImageIndex.value = index;
      showImageViewer.value = true;
    };
    
    // 關閉圖片查看器
    const closeImageViewer = () => {
      showImageViewer.value = false;
    };
    
    // 編輯評價相關方法
    const openEditModal = (review) => {
      console.log('打開編輯模態框，評價ID:', review.id);
      selectedReview.value = { ...review };
      showEditModal.value = true;
    };
    
    const closeEditModal = () => {
      showEditModal.value = false;
      selectedReview.value = null;
    };
    
    const updateReview = async (updatedReview) => {
      try {
        // 顯示處理中提示
        Swal.fire({
          title: '處理中...',
          text: '正在更新評價',
          allowOutsideClick: false,
          didOpen: () => {
            Swal.showLoading();
          }
        });
        
        // 發送更新請求
        await axios.put(`/api/reviews/${updatedReview.id}`, updatedReview, { timeout: 5000 });
        
        // 在本地更新評價
        const index = reviews.value.findIndex(r => r.id === updatedReview.id);
        if (index !== -1) {
          reviews.value[index] = { ...reviews.value[index], ...updatedReview };
        }
        
        // 成功提示
        Swal.fire({
          icon: 'success',
          title: '評價已更新',
          text: '您的評價已成功更新',
          confirmButtonColor: '#3a8c5f'
        });
        
        // 關閉編輯模態框
        closeEditModal();
      } catch (error) {
        console.error('更新評價失敗:', error);
        Swal.fire({
          icon: 'error',
          title: '更新失敗',
          text: '更新評價失敗，請稍後再試',
          confirmButtonColor: '#3a8c5f'
        });
      }
    };
    
    // 刪除評價相關方法 - 已增強
    const openDeleteModal = (review) => {
      console.log('打開刪除模態框，評價ID:', review.id);
      selectedReview.value = { ...review };
      showDeleteModal.value = true;
    };
    
    const closeDeleteModal = () => {
      showDeleteModal.value = false;
      selectedReview.value = null;
    };
    
 // 刪除評價函數
const deleteReview = async (reviewId) => {
  try {
    Swal.fire({
      title: '處理中...',
      text: '正在刪除評價',
      allowOutsideClick: false,
      didOpen: () => { Swal.showLoading(); }
    });
    
    // 確保參數以字符串形式正確傳遞
    const apiUrl = `/api/reviews/${reviewId}?userId=${currentUserId.value}`;
    console.log('發送刪除請求:', apiUrl);
    
    // 直接使用確切的URL格式，避免額外的參數處理
    const response = await axios.delete(apiUrl);
    
    // 在本地更新UI
    reviews.value = reviews.value.filter(r => r.id !== reviewId);
    totalElements.value = Math.max(0, totalElements.value - 1);
    
    Swal.fire({
      icon: 'success',
      title: '評價已刪除',
      timer: 1500,
      showConfirmButton: false
    });
    
    showDeleteModal.value = false;
    selectedReview.value = null;
  } catch (error) {
    console.error('刪除評價失敗:', error);
    
    Swal.fire({
      icon: 'error',
      title: '刪除失敗',
      text: '刪除評價失敗，請稍後再試',
      confirmButtonColor: '#3a8c5f'
    });
    
    showDeleteModal.value = false;
    selectedReview.value = null;
  }
};
    
    // 刪除回覆相關方法
    const openDeleteReplyModal = (review) => {
      selectedReview.value = { ...review };
      showDeleteReplyModal.value = true;
    };
    
    const closeDeleteReplyModal = () => {
      showDeleteReplyModal.value = false;
      selectedReview.value = null;
    };
    
    const deleteReply = async (reviewId) => {
  try {
    // 顯示處理中提示
    Swal.fire({
      title: '處理中...',
      text: '正在刪除回覆',
      allowOutsideClick: false,
      didOpen: () => {
        Swal.showLoading();
      }
    });
    
    // 發送刪除回覆請求，確保與後端API匹配
    await axios.delete(`/api/reviews/${reviewId}/reply`, { timeout: 5000 });
    
    // 在本地更新評價，移除回覆
    const index = reviews.value.findIndex(r => r.id === reviewId);
    if (index !== -1) {
      reviews.value[index].replyText = null;
    }

    // 成功提示
    Swal.fire({
      icon: 'success',
      title: '回覆已刪除',
      text: '回覆已成功刪除',
      confirmButtonColor: '#3a8c5f'
    });
    
    // 關閉刪除回覆模態框
    closeDeleteReplyModal();
  } catch (error) {
    console.error('刪除回覆失敗:', error);
    Swal.fire({
      icon: 'error',
      title: '刪除失敗',
      text: '刪除回覆失敗，請稍後再試',
      confirmButtonColor: '#3a8c5f'
    });
    
    // 添加：確保即使出錯也關閉模態框
    closeDeleteReplyModal();
  }
};
    
    // 編輯回覆相關方法
    const openEditReplyModal = (review) => {
      selectedReview.value = { ...review };
      showEditReplyModal.value = true;
    };
    
    const closeEditReplyModal = () => {
      showEditReplyModal.value = false;
      selectedReview.value = null;
    };
    
    // 更新回覆 - 增強版實現
    const updateReply = async (updatedData) => {
      try {
        // 立即更新UI
        const index = reviews.value.findIndex(r => r.id === updatedData.reviewId);
        if (index !== -1) {
          // 保存原值供回滾使用
          const originalText = reviews.value[index].replyText;
          
          // 更新UI
          reviews.value[index].replyText = updatedData.replyText;
          
          // 關閉模態框
          closeEditReplyModal();
          
          // 顯示成功提示
          Swal.fire({
            icon: 'success',
            title: '回覆已更新',
            text: '您的回覆已成功更新',
            timer: 1500, 
            showConfirmButton: false
          });
          
          // 嘗試多種API方式更新回覆
          submitReplyToAPI(updatedData).catch(error => {
            console.error('更新回覆API提交過程中出錯:', error);
          });
        }
      } catch (error) {
        console.error('更新回覆失敗:', error);
        Swal.fire({
          icon: 'error',
          title: '更新失敗',
          text: '更新回覆失敗，請稍後再試',
          confirmButtonColor: '#3a8c5f'
        });
        
        closeEditReplyModal();
      }
    };
    
    // 回覆評價相關方法 - 增強版
    const openReplyModal = (review) => {
      selectedReview.value = JSON.parse(JSON.stringify(review)); // 深度複製避免引用問題
      showReplyModal.value = true;
    };
    
    const closeReplyModal = () => {
      showReplyModal.value = false;
      selectedReview.value = null;
    };
    
    // 完全重構的回覆提交函數
    const submitReply = async (replyData) => {
      try {
        // 立即在UI上更新回覆
        const index = reviews.value.findIndex(r => r.id === replyData.reviewId);
        if (index !== -1) {
          // 立即更新UI
          reviews.value[index].replyText = replyData.replyText;
          
          // 無論API成功與否，先關閉模態框和加載提示
          setTimeout(() => {
            Swal.close();
            closeReplyModal();
            
            // 顯示成功提示
            Swal.fire({
              icon: 'success',
              title: '回覆已提交',
              text: '您的回覆已成功顯示',
              timer: 1500,
              showConfirmButton: false
            });
          }, 500);
          
          // 嘗試提交到API (但不阻塞UI流程)
          submitDirectReplyToAPI(replyData).catch(error => {
            console.error('回覆API提交過程中出錯:', error);
          });
        }
      } catch (error) {
        console.error('回覆評價失敗:', error);
        Swal.fire({
          icon: 'error',
          title: '回覆失敗',
          text: '回覆評價失敗，請稍後再試',
          confirmButtonColor: '#3a8c5f'
        });
        
        closeReplyModal();
      }
    };
    
    // 創建直接回覆的方法 - 完全重構
    const submitDirectReplyToAPI = async (replyData) => {
      const reviewId = replyData.reviewId;
      let success = false;
      
      // 紀錄開始嘗試API提交
      console.log('開始嘗試直接提交回覆到API，評價ID:', reviewId);
      console.log('回覆內容:', replyData.replyText);
      
      // 根據後端API規範，使用PUT方法和適當的payload格式
      try {
        console.log('嘗試使用PUT方法提交回覆');
        
        // 按照後端API規範構建payload
        const payload = {
          replyText: replyData.replyText
        };
        
        const response = await axios.put(
          `/api/reviews/${reviewId}/reply`,
          payload,
          {
            headers: {
              'Content-Type': 'application/json'
            },
            timeout: 8000
          }
        );
        
        console.log('回覆提交成功:', response.data);
        return response.data;
      } catch (error) {
        console.error('回覆提交失敗:', error);
        throw error;
      }
    };
    
    // 分離API提交邏輯 - 用於回覆和更新回覆
    const submitReplyToAPI = async (replyData) => {
      const reviewId = replyData.reviewId;
      
      // 紀錄開始嘗試API提交
      console.log('開始嘗試提交回覆到API，評價ID:', reviewId);
      
      // 根據後端API規範構建請求
      const payload = {
        replyText: replyData.replyText
      };
      
      try {
        const response = await axios.put(
          `/api/reviews/${reviewId}/reply`,
          payload,
          {
            headers: {
              'Content-Type': 'application/json'
            },
            timeout: 5000
          }
        );
        
        console.log('回覆更新成功:', response.data);
        return response.data;
      } catch (error) {
        console.error('回覆更新失敗:', error);
        throw error;
      }
    };

    // 新增評價到列表
    const addNewReview = (review) => {
      if (currentPage.value === 0 && props.searchParams.sortBy === 'createdAt' && props.searchParams.sortDirection === 'DESC') {
        reviews.value.unshift(review);
        
        if (reviews.value.length > pageSize.value) {
          reviews.value.pop();
        }
        
        totalElements.value += 1;
      } else {
        fetchReviews();
      }
    };

    
    // 應用加載時初始化
    onMounted(async () => {
      // 先測試API連接
      const apiTest = await testApiConnection();
      if (apiTest.success) {
        console.log('API連接測試成功！使用路徑:', apiTest.path);
        // 可以存儲成功的API路徑供後續請求使用
        sessionStorage.setItem('API_WORKING_PATH', apiTest.path);
      } else {
        console.error('API連接測試失敗！請確保後端服務正在運行');
        // 可以顯示提示給用戶
        error.value = 'API連接失敗，可能無法執行資料操作';
      }
      
      // 繼續原有的初始化
      fetchReviews();
    });
    
    // 提供公開方法以供父組件調用
    const applySearchFilters = () => {
      currentPage.value = 0;
      fetchReviews();
    };

    const clearSearchFilters = () => {
      currentPage.value = 0;
      fetchReviews();
    };

    const refreshReviews = () => {
      fetchReviews();
    };

    return { 
      reviews, 
      loading, 
      error, 
      currentPage, 
      totalPages, 
      totalElements, 
      displayPages, 
      currentUserId,
      getCampName, 
      getCampRegion, 
      formatDate, 
      changePage, 
      handleLike, 
      isCurrentUserReview,
      // 查看相關
      viewReview,
      viewImage,
      closeImageViewer,
      showImageViewer,
      selectedImages,
      selectedImageIndex,
      // 編輯相關
      showEditModal,
      openEditModal,
      closeEditModal,
      updateReview,
      // 刪除評價相關
      showDeleteModal,
      openDeleteModal,
      closeDeleteModal,
      deleteReview,
      // 刪除回覆相關
      showDeleteReplyModal,
      openDeleteReplyModal,
      closeDeleteReplyModal,
      deleteReply,
      // 編輯回覆相關
      showEditReplyModal,
      openEditReplyModal,
      closeEditReplyModal,
      updateReply,
      // 回覆相關
      showReplyModal,
      openReplyModal,
      closeReplyModal,
      submitReply,
      // 檢舉相關
      showReportModal,
      showReportReplyModal,
      openReportModal,
      closeReportModal,
      openReportReplyModal,
      closeReportReplyModal,
      submitReport,
      submitReplyReport,
      // 其他狀態
      isOwner,
      selectedReview,
      applySearchFilters,
      clearSearchFilters,
      refreshReviews,
      addNewReview,
      isImageLoading,
      handleImageLoaded,
      logImageError,
      getVisibleImages
    };
  }
};
</script>

<style scoped>
/* 首先定義墨綠色系色彩變數 */
:root {
  --forest-dark: #1E432E;
  --forest-medium: #356648;
  --forest-light: #5B8F6D;
}

/* 所有文字使用墨綠色的類 */
.text-forest {
  color: var(--forest-dark, #1E432E) !important;
}

.text-forest-light {
  color: var(--forest-medium, #356648) !important;
}

.review-list-container {
  max-width: 1100px;
  margin: 0 auto;
  padding: 20px;
  background-color: transparent;
  color: #1E432E;
  line-height: 1.6;
  width: 100%;
}

.loading-state {
  background-color: #ffffff;
  border-radius: 16px;
  padding: 30px;
  box-shadow: 0 2px 6px rgba(40, 80, 60, 0.08);
  border: 1px solid #BFE0C9;
}

.spinner-border {
  color: #47845D;
  width: 3rem;
  height: 3rem;
}

.empty-state {
  background-color: #ffffff;
  border-radius: 16px;
  padding: 40px 20px;
  box-shadow: 0 2px 6px rgba(40, 80, 60, 0.08);
  border: 1px solid #BFE0C9;
}

.empty-icon {
  font-size: 3rem;
  color: #47845D;
  margin-bottom: 15px;
  opacity: 0.7;
}

.empty-state h3 {
  font-weight: 600;
  margin-bottom: 10px;
}

.alert-box {
  display: flex;
  align-items: center;
  padding: 16px 20px;
  border-radius: 12px;
  margin-bottom: 20px;
  font-weight: 500;
}

.alert-danger {
  background-color: rgba(220, 53, 69, 0.1);
  color: #d32f2f;
  border: 1px solid rgba(220, 53, 69, 0.3);
}

.section-title {
  font-size: 1.8rem;
  color: #1E432E;
  margin-bottom: 1.8rem;
  font-weight: 700; /* 修改為700使更粗 */
  position: relative;
  padding-bottom: 0.8rem;
}

.section-title::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 0;
  width: 60px;
  height: 3px;
  background: linear-gradient(135deg, #47845D, #2A5D3C);
  border-radius: 3px;
}

.count {
  font-size: 1.1rem;
  font-weight: 500;
  color: #356648;
}

.review-item {
  background-color: #ffffff;
  border-radius: 16px;
  box-shadow: 0 2px 6px rgba(40, 80, 60, 0.08);
  padding: 25px;
  transition: all 0.3s ease;
  border: 1px solid #BFE0C9;
  position: relative;
}

.review-item:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 24px rgba(40, 80, 60, 0.15);
}

.review-header {
  padding-bottom: 15px;
  margin-bottom: 15px;
  border-bottom: 1px solid #BFE0C9;
}

/* 營地區域和名稱更大更粗 */
.camp-region, .camp-name {
  font-size: 1.4rem; /* 放大字體 */
  font-weight: 700; /* 更粗的字體 */
  color: #1E432E; /* 墨綠色 */
}

.camp-region {
  color: #1E432E;
}

.camp-name {
  color: #1E432E;
  text-decoration: underline; /* 保留下劃線 */
  text-underline-offset: 3px; /* 調整下劃線位置 */
  display: inline-block;
}

.camp-name:hover {
  color: #47845D;
}

/* 營地評價系統標題 */
.section-title {
  font-size: 1.8rem;
  color: #1E432E; /* 墨綠色 */
  margin-bottom: 1.8rem;
  font-weight: 700; /* 加粗 */
  position: relative;
  padding-bottom: 0.8rem;
}

.star-rating {
  display: inline-flex;
  line-height: 1;
  align-items: center;
}

.star {
  font-size: 1.3rem;
  color: #FFCB45 !important;
  margin-right: 2px;
  cursor: default;
  display: inline-block !important;
}

.star-empty {
  opacity: 0.35;
  color: #FFCB45 !important;
  display: inline-block !important;
}

.star-filled {
  opacity: 1;
  text-shadow: 0 0 3px rgba(255, 203, 69, 0.3);
  color: #FFCB45 !important;
  display: inline-block !important;
}

.overall-rating .star {
  font-size: 1.4rem;
}

.user-info {
  margin-bottom: 15px;
  position: relative; /* 用於相對定位管理按鈕 */
}

/* 修正管理按鈕區域 - 確保顯示在正確位置 */
.admin-actions {
  position: absolute;
  top: 0;
  right: 0;
  display: flex;
  gap: 10px;
  z-index: 10;
  background-color: rgba(255, 255, 255, 0.8);
  padding: 5px;
  border-radius: 8px;
}

/* 優化管理按鈕樣式，解決顯示問題 */
.admin-btn {
  padding: 6px 12px;
  border-radius: 6px;
  display: flex;
  align-items: center;
  gap: 5px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s ease;
  border: 1px solid;
  background-color: white;
}

.admin-btn i {
  font-size: 14px;
}

.edit-btn {
  color: #2A5D3C;
  border-color: #2A5D3C;
}

.edit-btn:hover {
  background-color: rgba(42, 93, 60, 0.1);
  transform: translateY(-2px);
}

.delete-btn {
  color: #dc3545;
  border-color: #dc3545;
}

.delete-btn:hover {
  background-color: rgba(220, 53, 69, 0.1);
  transform: translateY(-2px);
}

/* 優化回覆管理按鈕 */
.reply-actions {
  display: flex;
  gap: 8px;
}

.reply-edit-btn {
  color: #2A5D3C;
  border-color: #2A5D3C;
  padding: 4px 8px;
  font-size: 12px;
}

.reply-edit-btn:hover {
  background-color: rgba(42, 93, 60, 0.1);
  transform: translateY(-2px);
}

.reply-delete-btn {
  color: #dc3545;
  border-color: #dc3545;
  padding: 4px 8px;
  font-size: 12px;
}

.reply-delete-btn:hover {
  background-color: rgba(220, 53, 69, 0.1);
  transform: translateY(-2px);
}

.user-name {
  font-size: 1.1rem;
  color: #1E432E;
  font-weight: 600;
}

.review-date {
  color: #356648;
  font-size: 0.9rem;
}

.edited-tag {
  background-color: rgba(110, 171, 127, 0.1);
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 0.8rem;
  margin-left: 5px;
  color: #1E432E;
}

.review-text {
  color: #1E432E;
  line-height: 1.7;
  white-space: pre-line;
  margin-bottom: 15px;
}

.pros-cons {
  display: flex;
  flex-wrap: wrap;
  gap: 15px;
  margin-bottom: 20px;
}

.pros, .cons {
  padding: 15px;
  border-radius: 12px;
  flex: 1;
}

.pros {
  background-color: rgba(76, 175, 80, 0.08);
  border-left: 3px solid #47845D;
}

.cons {
  background-color: rgba(244, 67, 54, 0.08);
  border-left: 3px solid #f44336;
}

.label {
  font-weight: 600;
  color: #1E432E;
  margin-right: 5px;
  display: block;
  margin-bottom: 5px;
}

.value {
  color: #1E432E;
  line-height: 1.6;
}

.rating-details {
  padding: 15px 0;
  margin: 15px 0;
  border-top: 1px solid rgba(191, 224, 201, 0.5);
  border-bottom: 1px solid rgba(191, 224, 201, 0.5);
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
}

.rating-item {
  display: flex;
  align-items: center;
  flex: 1;
  min-width: 30%;
}

.rating-label {
  min-width: 85px;
  color: #1E432E;
  font-weight: 500;
}

.review-images {
  display: flex;
  gap: 12px;
  margin: 20px 0;
  flex-wrap: nowrap;
  overflow-x: auto;
  padding: 5px 2px;
}

.image-wrapper {
  width: 160px;
  height: 120px;
  border-radius: 10px;
  overflow: hidden;
  position: relative;
  cursor: pointer;
  border: 1px solid #BFE0C9;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
  transition: all 0.3s ease;
  flex-shrink: 0;
  background-color: #f8f9fa;
}

.image-wrapper:hover {
  transform: scale(1.03);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.review-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: all 0.3s ease;
  display: block;
}

.image-loading {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.03);
}

.image-overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.3);
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: all 0.3s ease;
  color: white;
  font-size: 1.5rem;
}

.image-wrapper:hover .image-overlay {
  opacity: 1;
}

.image-wrapper:hover .review-image {
  transform: scale(1.1);
}

.more-images {
  width: 60px;
  height: 120px;
  border-radius: 10px;
  background-color: rgba(0, 0, 0, 0.05);
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 600;
  color: #1E432E;
  cursor: pointer;
  transition: all 0.3s ease;
  border: 1px dashed #BFE0C9;
  flex-shrink: 0;
}

.more-images:hover {
  background-color: rgba(0, 0, 0, 0.1);
  transform: scale(1.03);
}

/* 評價回覆區塊樣式 */
.reply-section {
  background-color: rgba(76, 175, 80, 0.05);
  padding: 15px;
  border-radius: 12px;
  border-left: 3px solid #47845D;
  margin: 15px 0;
  position: relative;
}

.reply-header-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
}

.reply-header {
  color: #1E432E;
  font-weight: 600;
  margin: 0;
}

.reply-content {
  color: #1E432E;
  margin-bottom: 0;
  padding-left: 10px;
  line-height: 1.6;
}

/* 回覆檢舉按鈕樣式 */
.reply-footer {
  display: flex;
  justify-content: flex-end;
  margin-top: 10px;
}

.report-reply-btn {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 4px 10px;
  border-radius: 6px;
  border: 1px solid #ccc;
  background-color: white;
  color: #666;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.report-reply-btn:hover {
  background-color: #f0f0f0;
  color: #dc3545;
  border-color: #dc3545;
}

.report-reply-btn i {
  font-size: 10px;
}

/* 操作按鈕樣式 */
.review-actions {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 20px;
  padding-top: 15px;
  border-top: 1px solid rgba(191, 224, 201, 0.5);
  position: relative;
}

.action-group {
  display: flex;
  gap: 10px;
}

/* 點讚和檢舉按鈕 - 放在右下角 */
.right-bottom-actions {
  position: absolute;
  bottom: 0;
  right: 0;
  display: flex;
  gap: 10px;
}

.action-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 10px 15px;
  border-radius: 10px;
  font-size: 15px;
  cursor: pointer;
  transition: all 0.3s ease;
  background-color: #ffffff;
  border: 1px solid #BFE0C9;
  color: #1E432E;
  font-weight: 500;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.03);
  min-width: 90px; /* 確保按鈕寬度一致 */
  text-decoration: none; /* 確保連結樣式正確 */
}

/* 加強所有按鈕的交互反饋 */
.action-btn:hover {
  transform: translateY(-3px) !important;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1) !important;
}

.action-btn:active {
  transform: translateY(1px) !important;
}

.action-btn i {
  color: inherit;
}

.view-btn:hover, .edit-btn:hover {
  background-color: rgba(110, 171, 127, 0.1);
}

.like-btn {
  color: #1E432E;
}

.like-btn.active {
  background-color: rgba(110, 171, 127, 0.1);
  border-color: #2A5D3C;
  color: #1E432E;
}

.like-btn:hover, .like-btn.active:hover {
  background-color: rgba(110, 171, 127, 0.15);
}

.reply-btn {
  color: #17a2b8;
  border-color: #17a2b8;
  background-color: white;
}

.reply-btn:hover {
  background-color: rgba(23, 162, 184, 0.1);
}

/* 檢舉按鈕樣式 */
.report-btn {
  color: #6c757d;
  border-color: #6c757d;
}

.report-btn:hover {
  background-color: rgba(108, 117, 125, 0.1);
  color: #dc3545;
  border-color: #dc3545;
}

/* 新增的編輯和刪除按鈕替代樣式 */
.edit-btn-alt {
  color: #1E432E;
  border-color: #1E432E;
}

.edit-btn-alt:hover {
  background-color: rgba(30, 67, 46, 0.1);
}

.delete-btn-alt {
  color: #dc3545;
  border-color: #dc3545;
}

.delete-btn-alt:hover {
  background-color: rgba(220, 53, 69, 0.1);
}

/* 分頁區塊樣式 */
.pagination-container {
  display: flex;
  justify-content: center;
  margin-top: 30px;
}

.pagination {
  background-color: #ffffff;
  padding: 8px;
  border-radius: 30px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  border: 1px solid #BFE0C9;
  display: flex;
  gap: 5px;
}

.pagination .page-item {
  list-style: none;
}

.pagination .page-link {
  border: none;
  color: #1E432E;
  width: 36px;
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  transition: all 0.3s ease;
  text-decoration: none;
  font-weight: 500;
}

.pagination .page-item.active .page-link {
  background: linear-gradient(135deg, #2A5D3C, #47845D);
  color: white;
  box-shadow: 0 2px 5px rgba(42, 93, 60, 0.2);
}

.pagination .page-item:not(.active) .page-link:hover {
  background-color: rgba(110, 171, 127, 0.1);
  transform: translateY(-2px);
}

.pagination .page-item.disabled .page-link {
  color: #aaa;
  cursor: not-allowed;
}

/* 響應式調整 */
@media (max-width: 992px) {
  .rating-details {
    flex-direction: column;
    gap: 12px;
  }
}

@media (max-width: 768px) {
  .pros-cons {
    flex-direction: column;
  }
  
  .image-wrapper {
    width: 120px;
    height: 90px;
  }
  
  .more-images {
    width: 50px;
    height: 90px;
  }
  
  .right-bottom-actions {
    position: relative;
    margin-top: 15px;
    justify-content: flex-end;
    width: 100%;
  }
}

@media (max-width: 576px) {
  .review-actions {
    flex-direction: column;
    align-items: flex-start;
    gap: 12px;
  }
  
  .action-group {
    width: 100%;
    justify-content: space-between;
  }
  
  .section-title {
    font-size: 1.4rem;
  }
  
  .review-item {
    padding: 20px;
  }
}
</style>