<!-- src/components/ReviewItem.vue -->
<template>
  <div class="review-item">
    <!-- 評價頭部信息 -->
    <div class="review-header">
      <div class="user-info">
        <div class="user-avatar">{{ review.userName ? review.userName.charAt(0) : 'U' }}</div>
        <div>
          <h5 class="user-name">{{ review.userName || '匿名用戶' }}</h5>
          <p class="review-date">{{ formatDate(review.createdAt) }}</p>
        </div>
      </div>
      
      <div class="review-rating">
        <span v-for="i in 5" :key="i" class="star" :class="i <= review.overallRating ? 'filled' : 'empty'">★</span>
        <span class="rating-value">{{ review.overallRating }}</span>
      </div>
    </div>
    
    <!-- 評價內容 -->
    <div class="review-content">
      <p>{{ review.reviewText }}</p>
    </div>
    
    <!-- 評價圖片 -->
    <div class="review-images" v-if="review.imageUrls && review.imageUrls.length > 0">
      <div v-for="(url, index) in review.imageUrls.slice(0, 3)" :key="index" class="image-item">
        <img :src="url" :alt="`評價圖片 ${index + 1}`" @click="$emit('view-image', review.imageUrls, index)">
      </div>
    </div>
    
    <!-- 營地回覆 -->
    <div class="reply-section" v-if="review.replyText">
      <h4>營地方回覆：</h4>
      <p>{{ review.replyText }}</p>
    </div>
    
    <!-- 開發除錯用 - 顯示用戶ID信息 -->
    <div class="debug-info" style="background-color: #f5f5f5; padding: 5px; margin: 5px 0; font-size: 12px;">
      <p>目前登入 userId: {{ currentUserId }}</p>
      <p>這筆評價屬於 userId: {{ review.userId }}</p>
      <p>isAuthor 狀態: {{ isAuthor }}</p>
    </div>
    
    <!-- 直接添加評價操作按鈕 - 無論權限都先顯示所有按鈕 -->
    <div class="review-actions">
      <!-- 作者可見的編輯和刪除按鈕，暫時移除 v-if 條件方便測試 -->
      <div class="author-actions">
        <button class="action-btn edit-btn" @click="$emit('edit', review.id)">編輯</button>
        <button class="action-btn delete-btn" @click="$emit('delete', review.id)">刪除</button>
      </div>
      
      <!-- 所有人可見的檢舉按鈕 -->
      <button class="action-btn report-btn" @click="$emit('report', review.id)">檢舉</button>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    review: {
      type: Object,
      required: true
    },
    isAuthor: {
      type: Boolean,
      default: false
    },
    currentUserId: {
      type: [Number, String],
      default: null
    }
  },
  emits: ['edit', 'delete', 'report', 'view-image'],
  methods: {
    formatDate(dateString) {
      if (!dateString) return '';
      
      try {
        const date = new Date(dateString);
        return `${date.getFullYear()}年${date.getMonth() + 1}月${date.getDate()}日`;
      } catch (e) {
        return dateString;
      }
    }
  }
}
</script>

<style scoped>
.review-item {
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  padding: 20px;
  margin-bottom: 20px;
  position: relative;
}

.review-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
}

.user-info {
  display: flex;
  align-items: center;
}

.user-avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background-color: #2A5D3C;
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  margin-right: 10px;
}

.user-name {
  margin: 0;
  font-size: 16px;
  font-weight: 600;
  color: #333;
}

.review-date {
  margin: 0;
  font-size: 14px;
  color: #666;
}

.review-rating {
  display: flex;
  align-items: center;
}

.star {
  color: #FFCB45;
  font-size: 18px;
  margin-right: 2px;
}

.star.filled {
  opacity: 1;
}

.star.empty {
  opacity: 0.3;
}

.rating-value {
  margin-left: 5px;
  font-weight: bold;
  color: #333;
}

.review-content {
  margin-bottom: 15px;
  line-height: 1.6;
}

.review-images {
  display: flex;
  gap: 10px;
  margin-bottom: 15px;
  overflow-x: auto;
}

.image-item {
  width: 120px;
  height: 90px;
  border-radius: 4px;
  overflow: hidden;
  cursor: pointer;
}

.image-item img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.reply-section {
  background-color: #f8f8f8;
  padding: 15px;
  border-radius: 6px;
  margin-bottom: 15px;
  border-left: 3px solid #2A5D3C;
}

.reply-section h4 {
  margin-top: 0;
  margin-bottom: 10px;
  color: #2A5D3C;
  font-size: 16px;
}

.reply-section p {
  margin: 0;
}

/* 評價操作按鈕樣式 */
.review-actions {
  display: flex;
  justify-content: space-between;
  border-top: 1px solid #eee;
  padding-top: 15px;
  margin-top: 15px;
}

.author-actions {
  display: flex;
  gap: 10px;
}

.action-btn {
  padding: 8px 16px;
  border-radius: 4px;
  font-weight: 500;
  cursor: pointer;
  border: none;
  font-size: 14px;
  transition: all 0.2s;
}

.edit-btn {
  background-color: #4CAF50;
  color: white;
}

.edit-btn:hover {
  background-color: #45a049;
}

.delete-btn {
  background-color: #f44336;
  color: white;
}

.delete-btn:hover {
  background-color: #d32f2f;
}

.report-btn {
  background-color: #ff9800;
  color: white;
}

.report-btn:hover {
  background-color: #e68a00;
}

/* 除錯信息樣式 */
.debug-info {
  border: 1px dashed #ccc;
  border-radius: 4px;
  margin: 10px 0;
}

.debug-info p {
  margin: 3px 0;
  font-family: monospace;
}
</style>